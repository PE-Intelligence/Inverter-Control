This folder contains the code used for neural network training.
1. "main_seed.py" contains the python code used for NNLI training.
2. "Main_smallsignal_id_Seed.py" contains the python code used for NNSI training.
3. "Normalized_desire_1125.csv" contains the data for close-loop testing of NNLI.
4. "Normalized_desire_0515.csv" contains the data for close-loop testing of NNSI.
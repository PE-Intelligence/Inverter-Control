import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
import time
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# ---------- Config ----------
DATA_DIR = "SmallSignal_id"
N_IN     = 400          # small-signal input length (100 S/s x 4 s)
SCALE    = 0.4          # normalized [0,1] -> impedance [-0.4, 0] p.u.
SEEDS    = list(range(10))

# ---------- Load data once (shared across all seeds) ----------
inputs_train  = np.array(pd.read_csv(f"{DATA_DIR}/Inputs_train_0512.csv",  header=None))[:, :N_IN]
outputs_train = np.array(pd.read_csv(f"{DATA_DIR}/Targets_train_0512.csv", header=None))
inputs_test   = np.array(pd.read_csv(f"{DATA_DIR}/Inputs_test_0512.csv",   header=None))[:, :N_IN]
outputs_test  = np.array(pd.read_csv(f"{DATA_DIR}/Targets_test_0512.csv",  header=None))
inputs_validation   = np.array(pd.read_csv(f"{DATA_DIR}/Inputs_validation_0512.csv",   header=None))[:, :N_IN]
outputs_validation  = np.array(pd.read_csv(f"{DATA_DIR}/Targets_validation_0512.csv",  header=None))

inputs_desire = np.array(pd.read_csv(f"{DATA_DIR}/Normalized_desire_0515.csv", header=None))[:, :N_IN]

print("Total Number of training Dataset is:", len(inputs_train))


def r2_score(y_true, y_pred):
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1.0 - ss_res / ss_tot


def build_and_train(seed):
    # ---- fix all random sources; only training randomness varies ----
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        0.001, decay_steps=500, decay_rate=0.99, staircase=True)   # NN_SI uses 0.005

    # Normalization layer is stateful after adapt -> rebuild per seed
    Normlayer1 = tf.keras.layers.Normalization()
    Normlayer1.adapt(inputs_train)

    model = tf.keras.Sequential()
    model.add(Normlayer1)
    model.add(tf.keras.layers.Dense(64, activation='relu'))
    model.add(tf.keras.layers.Dense(16, activation='relu'))
    model.add(tf.keras.layers.Dense(1,  activation='sigmoid'))

    opt = tf.keras.optimizers.Adam(learning_rate=lr_schedule)
    model.compile(optimizer=opt, loss='mse', metrics=['mse'])

    history = model.fit(inputs_train, outputs_train,
                        epochs=10000, batch_size=500,
                        validation_data=(inputs_validation, outputs_validation),
                        verbose=0)

    pred_train = model.predict(inputs_train, verbose=0)
    pred_test  = model.predict(inputs_test,  verbose=0)

    # ---- save per-seed test predictions now, so no re-run is needed later ----
    pd.DataFrame({
        "true_norm":   outputs_test.flatten(),
        "pred_norm":   pred_test.flatten(),
        "true_pu":     outputs_test.flatten() * SCALE - SCALE,
        "pred_pu":     pred_test.flatten()    * SCALE - SCALE,
        "residual_pu": (pred_test.flatten() - outputs_test.flatten()) * SCALE,
    }).to_csv(f"{DATA_DIR}/scatter_data_SI_seed{seed}.csv", index=False)

    m = {
        'seed':      seed,
        'MAE_train': np.abs(pred_train - outputs_train).mean(),
        'MSE_train': np.square(pred_train - outputs_train).mean(),
        'R2_train':  r2_score(outputs_train, pred_train),
        'MAE_test':  np.abs(pred_test - outputs_test).mean(),
        'MSE_test':  np.square(pred_test - outputs_test).mean(),
        'R2_test':   r2_score(outputs_test, pred_test),
    }
    return model, history, m


# ---------- Run all seeds ----------
results, models, histories = [], {}, {}

t0 = time.perf_counter()
for s in SEEDS:
    model, history, m = build_and_train(s)
    results.append(m); models[s] = model; histories[s] = history
    print(f"seed {s:2d} | test  MAE={m['MAE_test']:.4f}  "
          f"MSE={m['MSE_test']:.3e}  R2={m['R2_test']:.4f}")
print("Total elapsed time:", time.perf_counter() - t0)

# ---------- Summary ----------
df = pd.DataFrame(results)
df.to_csv(f"{DATA_DIR}/seed_results_SI.csv", index=False)

print(f"\n===== Summary over {len(SEEDS)} seeds (mean +/- std), normalized scale =====")
for k in ['MAE_test', 'MSE_test', 'R2_test', 'MAE_train', 'MSE_train', 'R2_train']:
    print(f"{k:10s}: {df[k].mean():.4f} +/- {df[k].std():.4f}")

print("\n===== Test metrics in original p.u. scale =====")
print(f"MAE_test : {df['MAE_test'].mean()*SCALE:.4f} +/- {df['MAE_test'].std()*SCALE:.4f} p.u.")
print(f"MSE_test : {df['MSE_test'].mean()*SCALE**2:.6f} +/- {df['MSE_test'].std()*SCALE**2:.6f}")
print(f"R2_test  : {df['R2_test'].mean():.4f} +/- {df['R2_test'].std():.4f}   (dimensionless)")

# ---------- Worst / best / representative seed ----------
worst_seed = int(df.loc[df['MSE_test'].idxmax(), 'seed'])
best_seed  = int(df.loc[df['MSE_test'].idxmin(), 'seed'])
rep_seed   = int(df.loc[(df['R2_test'] - df['R2_test'].mean()).abs().idxmin(), 'seed'])
print(f"\nWorst seed (max test MSE): {worst_seed}")
print(f"Best  seed (min test MSE): {best_seed}")
print(f"Representative seed (R2 closest to mean): {rep_seed}  -> use for Extended Data Fig. 3")

# ---------- Export predictions on the desired-waveform inputs ----------
for tag, sd in [("worstseed", worst_seed), ("repseed", rep_seed)]:
    np.savetxt(f"{DATA_DIR}/Xv_desire_pred_0515_{tag}{sd}.csv",
               models[sd].predict(inputs_desire, verbose=0), delimiter=',')
    models[sd].save(f"{DATA_DIR}/saved_model_SI_{tag}{sd}")

# ---------- Loss curve of the representative seed ----------
plt.rcParams["figure.figsize"] = (9, 6)
h = histories[rep_seed]
plt.plot(h.history['loss'],     '-r.', label='Training Loss')
plt.plot(h.history['val_loss'], '--b.', label='Validation Loss')
plt.title(f'Loss (representative seed = {rep_seed})')
plt.xlabel('Epochs'); plt.ylabel('Loss'); plt.legend(); plt.semilogy(); plt.grid()
plt.show()
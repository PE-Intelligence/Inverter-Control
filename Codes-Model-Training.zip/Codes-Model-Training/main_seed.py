import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
import time
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# ---------- Load data once (shared across all seeds) ----------
inFilename   = "Inputs_train_1125.csv"
outFilename  = "Targets_train_1125.csv"
inFilename2  = "Inputs_test_1125.csv"
outFilename2 = "Targets_test_1125.csv"
inFilename3  = "Inputs_validation_1125.csv"
outFilename3 = "Targets_validation_1125.csv"

inputs_train  = np.array(pd.read_csv(inFilename,   header=None))[:, :80]
outputs_train = np.array(pd.read_csv(outFilename,  header=None))
inputs_test   = np.array(pd.read_csv(inFilename2,  header=None))[:, :80]
outputs_test  = np.array(pd.read_csv(outFilename2, header=None))
inputs_validation   = np.array(pd.read_csv(inFilename2,  header=None))[:, :80]
outputs_validation  = np.array(pd.read_csv(outFilename2, header=None))

num_inputs_train = len(inputs_train)
print("Total Number of training Dataset is:", num_inputs_train)

# Desired-waveform inputs (for exporting the chosen seed's predictions)
inputs_desire = np.array(pd.read_csv("Normalized_desire_1125.csv", header=None))[:, :80]

SEEDS = list(range(10))   # 10 seeds: 0..9


def r2_score(y_true, y_pred):
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1.0 - ss_res / ss_tot


def build_and_train(seed):
    # ---- fix all random sources so variance reflects training randomness only ----
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        0.02, decay_steps=500, decay_rate=0.99, staircase=True)

    # Normalization layer must be re-created per seed (state depends on adapt)
    Normlayer1 = tf.keras.layers.Normalization()
    Normlayer1.adapt(inputs_train)

    model = tf.keras.Sequential()
    model.add(Normlayer1)
    model.add(tf.keras.layers.Dense(64, activation='relu'))
    model.add(tf.keras.layers.Dense(16, activation='relu'))
    model.add(tf.keras.layers.Dense(1,  activation='sigmoid'))

    opt = tf.keras.optimizers.Adam(learning_rate=lr_schedule)
    model.compile(optimizer=opt, loss='mse', metrics=['mse'])

    history = model.fit(inputs_train, outputs_train,
                        epochs=10000, batch_size=500,
                        validation_data=(inputs_validation, outputs_validation),
                        verbose=0)   # quiet; set to 1 if you want per-epoch logs

    # ---- metrics ----
    pred_train = model.predict(inputs_train, verbose=0)
    pred_test  = model.predict(inputs_test,  verbose=0)

    m = {
        'seed':      seed,
        'MAE_train': np.abs(pred_train - outputs_train).mean(),
        'MSE_train': np.square(pred_train - outputs_train).mean(),
        'R2_train':  r2_score(outputs_train, pred_train),
        'MAE_test':  np.abs(pred_test - outputs_test).mean(),
        'MSE_test':  np.square(pred_test - outputs_test).mean(),
        'R2_test':   r2_score(outputs_test, pred_test),
    }
    return model, history, m


# ---------- Run all seeds ----------
results = []
models  = {}
histories = {}

t0 = time.perf_counter()
for s in SEEDS:
    model, history, m = build_and_train(s)
    results.append(m)
    models[s] = model
    histories[s] = history
    print(f"seed {s:2d} | test  MAE={m['MAE_test']:.4f}  "
          f"MSE={m['MSE_test']:.3e}  R2={m['R2_test']:.4f}")
print("Total elapsed time:", time.perf_counter() - t0)

# ---------- Summary: mean +/- std over seeds ----------
df = pd.DataFrame(results)
df.to_csv("seed_results_1125.csv", index=False)

print("\n===== Summary over", len(SEEDS), "seeds (mean +/- std) =====")
for k in ['MAE_test', 'MSE_test', 'R2_test', 'MAE_train', 'MSE_train', 'R2_train']:
    print(f"{k:10s}: {df[k].mean():.4f} +/- {df[k].std():.4f}")

# ---------- Identify the WORST seed (largest test MSE) ----------
worst_idx  = df['MSE_test'].idxmax()
worst_seed = int(df.loc[worst_idx, 'seed'])
best_idx   = df['MSE_test'].idxmin()
best_seed  = int(df.loc[best_idx, 'seed'])
print(f"\nWorst seed (max test MSE): {worst_seed}  "
      f"(R2={df.loc[worst_idx, 'R2_test']:.4f})")
print(f"Best  seed (min test MSE): {best_seed}  "
      f"(R2={df.loc[best_idx, 'R2_test']:.4f})")

# ---------- Export the WORST seed's predictions for closed-loop testing ----------
worst_model = models[worst_seed]
np.savetxt(f"Xv_desire_pred_1125_worstseed{worst_seed}.csv",
           worst_model.predict(inputs_desire, verbose=0), delimiter=',')
worst_model.save(f"saved_model/model_worstseed{worst_seed}")

# (optional) also export best seed for comparison
np.savetxt(f"Xv_desire_pred_1125_bestseed{best_seed}.csv",
           models[best_seed].predict(inputs_desire, verbose=0), delimiter=',')

# ---------- Loss curve of the worst seed ----------
plt.rcParams["figure.figsize"] = (9, 6)
h = histories[worst_seed]
plt.plot(h.history['loss'],     '-r.', label='Training Loss')
plt.plot(h.history['val_loss'], '--b.', label='Validation Loss')
plt.title(f'Loss (worst seed = {worst_seed})')
plt.xlabel('Epochs'); plt.ylabel('Loss'); plt.legend(); plt.semilogy(); plt.grid()
plt.show()
This folder contains the data to train and test NNSI.

The row number is the sample number in each dataset, while the column number contains 400 sampled active power (P).